package com.ssafy.model.dao;

import java.util.LinkedList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ssafy.config.MyBatis;
import com.ssafy.model.dto.Product;

public class ProductDAOImp implements ProductDAO{
	private SqlSession session = MyBatis.getSqlSession();
	@Override
	public void insertProduct(SqlSession session, Product product) {
		session.insert("product.insert",product);
	}

	@Override
	public void updateProduct(SqlSession session, Product product) {
		// TODO Auto-generated method stub
		session.update("product.update",product);
	}

	@Override
	public void deleteProduct(String gno) {
		session.delete("product.delete", gno);
		
	}

	@Override
	public Product search(String gno) {
		return session.selectOne("product.search", gno);
	}

	@Override
	public List<Product> searchAll() {
		// TODO Auto-generated method stub
		
		List<Product> products = session.selectList("product.searchAll");
		return products;
	}



}
