package com.ssafy.test;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ssafy.config.MyBatis;
import com.ssafy.model.dao.ProductDAO;
import com.ssafy.model.dao.ProductDAOImp;
import com.ssafy.model.dto.Member;
import com.ssafy.model.dto.Product;
import com.ssafy.model.dto.ProductException;

public class ProductTest {

	public static void main(String[] args) {
		Product product = new Product("13", "가가가", "10000", "가가가가가가가");
		ProductDAO dao = new ProductDAOImp();

		SqlSession session = null;
		// 등록
//		try {
//			session = MyBatis.getSqlSession();
//			dao.insertProduct(session, product);
//			session.commit();
//		} catch (Exception e) {
//			e.printStackTrace();
//			session.rollback();
//			throw new ProductException("상품 등록 중 오류 발생");
//		}
		
//		업데이트 
		session = null;
		try {
			session = MyBatis.getSqlSession();
			dao.updateProduct(session, product);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
			throw new ProductException("상품 수정 중 오류 발생");
		}
		
		//gno=12 물건 찾기
		String gno="12";
		try {
			System.out.println(dao.search(gno));
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("상품 조회중 오류 발생");			
		}
		
		//search all
		try {
		List<Product> products= dao.searchAll();
		for (Product pr : products) {
			System.out.println(pr);
		}
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		//상품 삭제
		dao.deleteProduct(gno);
	}
}
