package com.ssafy.model.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ssafy.config.MyBatis;
import com.ssafy.model.dao.ProductDAO;
import com.ssafy.model.dao.ProductDAOImp;
import com.ssafy.model.dto.Product;
import com.ssafy.model.dto.ProductException;

public class ProductServiceImp implements ProductService {
	private ProductDAO dao = new ProductDAOImp();

	@Override
	public Product search(String gno) {
		try {
			return dao.search(gno);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("상품 조회중 오류 발생");			
		}
	}

	@Override
	public List<Product> searchAll() {
		try {
			System.out.println(dao.searchAll());
			return dao.searchAll();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("전체 상품 조회중 오류 발생");			
		}
	}

	@Override
	public void add(Product product) {
		SqlSession session = null;
		try {
			session = MyBatis.getSqlSession();
			dao.insertProduct(session, product);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
			throw new ProductException("상품 등록 중 오류 발생");
		}
		
	}

	@Override
	public void update(Product product) {
		SqlSession session = null;
		try {
			session = MyBatis.getSqlSession();
			dao.updateProduct(session, product);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.rollback();
			throw new ProductException("상품 수정 중 오류 발생");
		}
		
		
	}

	@Override
	public void remove(String gno) {
		dao.deleteProduct(gno);
	}

	
}
