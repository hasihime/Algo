package com.ssafy.pms.model.dto;

public class Product {
	private String gno;
	private String brand;
	private String price;
	private String info;

	public Product() {

	}

	public Product(String gno, String brand, String price, String info) {
		super();
		this.gno = gno;
		this.brand = brand;
		this.price = price;
		this.info = info;
	}

	public String getGno() {
		return gno;
	}

	public void setGno(String gno) {
		this.gno = gno;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	@Override
	public String toString() {
		return "Product [gno=" + gno + ", brand=" + brand + ", price=" + price + ", info=" + info + "]";
	}

}
