package com.ssafy.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.pms.model.dto.Product;
import com.ssafy.pms.model.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	private ProductService service;
	
	@ExceptionHandler
	public ModelAndView handler(Exception e) {
		ModelAndView mav = new ModelAndView("Error");
		mav.addObject("msg", e.getMessage());
		return mav;
	}
	
	@GetMapping("product.do")
	public String searchproduct() {
		return "redirect:search.jsp";
	}
	@PostMapping("deleteProduct.do")
	public String deleteProduct(@RequestParam String num) {
		service.delete(num);
		return "redirect:searchProduct.do";
	}

	@GetMapping("search.do")
	public String search(Model model, String num) {
		model.addAttribute("product", service.search(num));
		return "pms/ProductView";
	}
	@GetMapping("searchProduct.do")
	public String searchProduct(Model model) {
		model.addAttribute("list", service.searchAll());
		return "pms/ProductList";
	}
	@GetMapping("regProduct.do")
	public String regProduct() {
		return "pms/ProductReg";
	}
	
	@PostMapping("saveProduct.do")
	public String saveProduct(Product product) {
		service.insert(product);
		return "redirect:Result.jsp";
	}
	
	
	

}







































