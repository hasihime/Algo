package com.ssafy.pms.model.dao;

import java.util.List;

import com.ssafy.pms.model.dto.Product;
import com.ssafy.pms.model.dto.UserInfo;

public interface ProductDao {
	public void 	insert(Product product);
	public void 	delete(String num);
	public Product	search(String num);
	public List<Product>	searchAll();
	public UserInfo findUser(String id);
}










