package com.ssafy.pms.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.pms.model.dao.ProductDao;
import com.ssafy.pms.model.dto.Product;
import com.ssafy.pms.model.dto.ProductException;
import com.ssafy.pms.model.dto.UserInfo;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductDao dao;
		
	public void insert(Product phone) {
		try {
			dao.insert(phone);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("저장 중 오류가 발생했습니다. ");
		}
	}
	public void delete(String num) {
		try {
			dao.delete(num);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("삭제 중 오류가 발생했습니다. ");
		}
	}
	public Product search(String num) {
		try {
			return dao.search(num);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("검색 중 오류가 발생했습니다. ");
		}
	}
	public List<Product> searchAll() {
		try {
			return dao.searchAll();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("검색 중 오류가 발생했습니다. ");
		}
	}
	public boolean login(String id, String pw) {
		try {
			UserInfo user = dao.findUser(id);
			if(user == null) throw new ProductException("등록된 아이디가 아닙니다.");
			if(pw == null || !pw.equals(user.getPw())) {
				throw new ProductException("비밀번호 오류 ");
			}
			return true;
		}catch (Exception e) {
			e.printStackTrace();
			if (e instanceof ProductException) {
				throw e;
			}else {
				throw new ProductException("인증 처리 중 오류가 발생했습니다.");
			}
		}
	}
}





