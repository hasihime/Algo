package com.ssafy.pms.model.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.pms.model.dto.Product;
import com.ssafy.pms.model.dto.UserInfo;

@Repository
public class ProductDaoImpl implements ProductDao {
	@Autowired
	private SqlSession session;
	
	String ns="sql.pms.";
	public void insert(Product product) {
		session.insert(ns+"insert", product);
	}
	public void delete(String num) {
		session.delete(ns+"delete", num);
	}
	public Product search(String num) {
		return session.selectOne(ns+"search", num);
	}
	public List<Product> searchAll() {
		return session.selectList(ns+"searchAll");
	}
	public UserInfo findUser(String id) {
		return session.selectOne(ns+"findUser", id);
	}
}



