package com.ssafy.model.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.Product;

@Repository
public class ProductDaoImpl implements ProductDao {

	private String ns = "sql.Product.";
	@Autowired
	private SqlSession session;

	public Product search(String no) {
		return session.selectOne(ns + "search", no);
	}

	public List<Product> searchall() {

		return session.selectList(ns + "searchall");
	}

	public void insert(Product Product) {
		System.out.println(Product.toString());
		session.insert(ns + "insert", Product);
		System.out.println("입력 완료");

	}


}
