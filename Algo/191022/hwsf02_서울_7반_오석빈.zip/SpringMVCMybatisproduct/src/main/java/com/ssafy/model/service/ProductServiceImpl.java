package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dao.ProductDao;
import com.ssafy.model.dto.Product;
import com.ssafy.model.dto.ProductException;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductDao dao;

	public Product search(String no) {
		try {
			return dao.search(no);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("Product 조회중 오류발생");
		}
		
	}

	public List<Product> searchall() {
		try {
			return dao.searchall();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("Product 목록 조회중 오류발생");
		}
		 
	}

	public void insert(Product Product) {
		try {
			dao.insert(Product);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("Product 등록중 오류발생");
		}

	}

}
