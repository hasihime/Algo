package com.ssafy.model.dao;

import java.util.List;

import com.ssafy.model.dto.Product;

public interface ProductDao {

	public Product search(String no);

	public List<Product> searchall();

	public void insert(Product Product);

}
