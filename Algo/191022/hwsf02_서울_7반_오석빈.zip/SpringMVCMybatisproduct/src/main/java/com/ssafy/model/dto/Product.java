package com.ssafy.model.dto;

import java.io.Serializable;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;
public class Product implements Serializable {
	private int no        	 ;
	private String id        ;
	
	
	
	public Product() {
		super();
	}
	public Product(String id, String title, String name, String price, String info) {
		super();
		this.id = id;
		this.title = title;
		this.name = name;
		this.price = price;
		this.info = info;
	}
	@Override
	public String toString() {
		return "Product [no=" + no + ", id=" + id + ", title=" + title + ", name=" + name + ", price=" + price
				+ ", info=" + info + "]";
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	private String title     ;
	private String name  ;
	private String price  ;
	private String info    ;
}
