import java.util.Scanner;

public class Main1_���ڿ� {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		int N=sc.nextInt();
		
		int cnt=0;
		int num=666;
		while(cnt<N) {
			String str=num+"";
			if (str.contains("666")) {
				cnt++;
			}
		
			num++;
		}
			System.out.println(--num);
	}

}
