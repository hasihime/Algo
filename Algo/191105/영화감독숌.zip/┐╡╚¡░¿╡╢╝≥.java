import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ��ȭ������ {

	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine());
		int m = n;
		int i = 665;
		int result = 0;
		while (n != 0) {
			i++;
			int movie = i;

			if (movie % 1000 == 666) {
				n--;
				result = movie;
				continue;
			}
			
			while (movie > 999) {
				movie /= 10;
				if (movie % 1000 == 666) {
					n--;
					result = i;
					break;
				}
			}
			
		}
		System.out.println(result);
	}

}
