package com.ssafy.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
/*
 * @controller
 * 	- bean으로 등록하는 Annotation
 * 	- Controller 역할을 하는 클래스로 bean이 등록됨
 */


public class MainController {
@RequestMapping("hello.do")
	/**
	 * 	1.@RequestMapping
	 * 	- 요청 처리 등록
	 * 	- HandlerMapper에 요청 URL을 key로 처리할 함수를 value로 등록
	 * 	- 형식
	 * 	@requestMapping(value=url, method=전송방식)
	 * 		method :생략시 모든 전송방식 지원
	 * 	ex) @RequestMapping(value="hello.do",method=RequestMethod.GET)
	 * 	ex) @RequestMapping(value="hello.do",method=RequestMethod.POST)
	 * 		
	 * 		- spring ver 4.xx			=>pom.xml에서 spring version 변경
	 * 			@GetMapping(value=url)	=>get 방식으로 요청
	 * 			@PostMapping(value=url)	=>post 방식으로 요청
	 * 
	 * 	1.1 get방식 처리 예제
	 * 
	 * 
	 * 
	 * 	2. 인자
	 * 	- 요청 데이터 처리
	 * 		2.1 String
	 * 			- 인자 명으로 요청 데이터 추출
	 * 				String 인자명= request.getParameter("인자명");
	 * 			- 요청 데이터로 이름으로 데이터가 전송되지 않았거나
	 * 			 요청 패킷에 데이터명이 없어도 error 발생하지 않는다.		
	 * 
	 *		 2.2 Primitive
	 * 			- 인자 명으로 요청 데이터 추출
	 * 				ex) int price
	 * 					int price= Integer.parseInt(request.getParameter("price"));
	 * 			- 요청 데이터로 이름으로 데이터가 전송되지 않으면 500번 에러
	 * 			 요청 패킷에 데이터명이 없거나 잘못된 format이면 400번 error 발생한다.	
	 * 		
	 * 		2.3 @RequestParam String or Primitive
	 * 			- 형식
	 * 			@RequestParam(value='요청데이터명', required, defultValue)	
	 * 				value
	 * 					-  요청데이터명
	 * 					-  생략하면 인자명으로 요청 데이타를 추출
	 * 
	 * 				required
	 * 					true : 요청 데이터가 없는 경우 error 발생
	 * 				defaultValue
	 * 					- 요청 데이터가 없는 경우 기본값으로 사용됨
	 * 	 */

//2.3
@GetMapping("hello.do")
public String hello(@RequestParam(defaultValue="5000") int msg) {
	System.out.println("전송 데이타 msg : "+msg);
	return "hello.jsp";
	
}



//@GetMapping("hello.do")
//public String hello(@RequestParam(required=true) String msg) {
//	System.out.println("전송 데이타 msg : "+msg);
//	return "hello.jsp";
//	
//}


// 2.2 인자를 primitive로 전달 받는 경우
//@GetMapping("hello.do")
//public String hello(int msg) {
//	System.out.println("전송 데이타 msg : "+msg);
//	return "hello.jsp";
//	
//}


// 	2.1인자를 String으로 전달받은 경우
//@GetMapping("hello.do")
//public String hello(String msg) {
//	System.out.println("전송 데이타 msg : "+msg);
//	return "hello.jsp";
//	
//}


	//1.1 예제
//	@GetMapping("hello.do")
//	public String hello() {
//		return "hello.jsp";
//	}
	
}
