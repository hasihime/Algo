package com.ssafy.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.dao.ProductDAO;
import com.ssafy.model.dto.Product;
import com.ssafy.model.dto.ProductException;

public class ProductServiceImp implements ProductService {
	private ProductDAO dao;
	
	public ProductServiceImp() {
		System.out.println("ProductServiceImp()");
	}
	

	public ProductServiceImp(ProductDAO dao) {
		super();
		this.dao = dao;
	}


	@Override
	public Product search(String gno) {
		try {
			Product product = dao.search(gno);
			if (product == null) {
				throw new ProductException("등록되지 않은 물건입니다.");
			} else {
				return product;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException();
		}
	}

	@Override
	public List<Product> searchAll() {
		try {
			return dao.searchAll();
		} catch (SQLException e) {
			throw new ProductException();
		}
	}


	@Override
	public void add(Product product) {
		try {
			Product find = dao.search(product.getGno());
			if (find != null) {
				throw new ProductException("이미 등록된 물건입니다.");
			} else {
				dao.add(product);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException();
		}

	}

	@Override
	public void update(Product product) {
		// TODO Auto-generated method stub

	}

	@Override
	public void remove(String gno) {
		
		try {
			Product find = dao.search(gno);
			System.out.println(find);
			if(find == null) {
				throw new ProductException("삭제할 상품이 없습니다.");
			}else {
				dao.remove(gno);
				System.out.println("삭제 완료");
			}
		} catch (SQLException e) {
			throw new ProductException();
		}

	}

}
