package com.ssafy.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssafy.model.service.ProductService;

public class DITest {

	public static void main(String[] args) {
		BeanFactory con =new ClassPathXmlApplicationContext("com/ssafy/config/beans.xml");
		
		ProductService product=con.getBean(ProductService.class);
		
		System.out.println(product.search("12"));

	}

}
